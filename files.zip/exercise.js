// api/exercise.js
import { callClaude } from './_lib/anthropic.js';
import { PROMPTS, PROMPT_VERSION } from './_lib/prompts.js';
import {
  sanitizeTopicCode,
  validateExercise,
  parseJsonStrict,
  GuardrailError,
} from './_lib/guardrails.js';
import {
  checkVocabularyUsage,
  detectLanguageMix,
  exerciseStem,
  checkDuplicate,
} from './_lib/output-guardrails.js';
import { checkDifficulty } from './_lib/difficulty.js';
import { checkTopicRelevance } from './_lib/topic-relevance.js';
import { checkTopicStructure } from './_lib/topic-structure.js';
import { retrieveGrammarContext } from './_lib/rag.js';
import { getSupabase } from './_lib/supabase.js';

const MIN_USER_VOCAB_FOR_LLM = 5;
const TARGET_VOCAB_SIZE = 20;
const RECENT_HISTORY_LIMIT = 8;
const MAX_GENERATION_ATTEMPTS = 3;

// Relaxed thresholds — A1-A2 with small vocab pool naturally has many "unknown" words
const VOCAB_UNKNOWN_RATIO_THRESHOLD = 0.5;
const RECENT_DEDUP_WINDOW = 30;
const DEDUP_SIMILARITY_THRESHOLD = 0.8;

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function pickPersonalizedTopic(supabase, fallbackCode) {
  const { data, error } = await supabase
    .from('mistakes')
    .select('topic')
    .order('created_at', { ascending: false })
    .limit(50);
  if (error || !data || data.length === 0) return fallbackCode;
  const counts = new Map();
  for (const m of data) {
    if (!m.topic) continue;
    counts.set(m.topic, (counts.get(m.topic) || 0) + 1);
  }
  if (counts.size === 0) return fallbackCode;
  const entries = [...counts.entries()];
  const total = entries.reduce((s, [, c]) => s + c, 0);
  let r = Math.random() * total;
  for (const [topic, count] of entries) {
    r -= count;
    if (r <= 0) return topic;
  }
  return entries[0][0];
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const {
      topicCode: rawCode,
      type,
      recentSeedWordIds = [],
      recentSentences = [],
      personalize = false,
    } = body || {};

    let topicCode = sanitizeTopicCode(rawCode);
    if (!['fill_gap', 'multiple_choice', 'sentence_building'].includes(type)) {
      throw new GuardrailError('Invalid exercise type', 'INVALID_TYPE');
    }
    if (!Array.isArray(recentSeedWordIds)) {
      throw new GuardrailError('recentSeedWordIds must be array', 'INVALID_TYPE');
    }
    if (!Array.isArray(recentSentences)) {
      throw new GuardrailError('recentSentences must be array', 'INVALID_TYPE');
    }

    const supabase = getSupabase();

    // ---- PERSONALIZATION ----
    if (personalize) {
      try {
        const personalized = await pickPersonalizedTopic(supabase, topicCode);
        if (
          personalized &&
          (type !== 'sentence_building' || personalized.startsWith('9'))
        ) {
          topicCode = sanitizeTopicCode(personalized);
        }
      } catch (e) {
        console.error('[personalize]', e);
      }
    }

    if (type === 'sentence_building' && !topicCode.startsWith('9')) {
      throw new GuardrailError(
        'sentence_building is only available for word-order (zinnen) topics',
        'TYPE_TOPIC_MISMATCH'
      );
    }

    // ---- LOAD VOCAB ----
    const { data: userVocab, error: vErr } = await supabase
      .from('vocabulary')
      .select('word_nl, word_ru, word_en, part_of_speech, article, level')
      .order('created_at', { ascending: false })
      .limit(100);
    if (vErr) throw new Error(`Supabase: ${vErr.message}`);
    const userWords = userVocab || [];

    let seedSample = [];
    let usedSeedIds = [];
    const needSeed =
      userWords.length < MIN_USER_VOCAB_FOR_LLM
        ? TARGET_VOCAB_SIZE
        : Math.max(0, TARGET_VOCAB_SIZE - userWords.length);
    if (needSeed > 0) {
      const recents = (recentSeedWordIds || []).slice(0, RECENT_HISTORY_LIMIT);
      let query = supabase
        .from('seed_words')
        .select('id, word_nl, word_ru, word_en, part_of_speech, article, level')
        .limit(needSeed * 2 + recents.length);
      if (recents.length > 0) {
        query = query.not('id', 'in', `(${recents.map((id) => `"${id}"`).join(',')})`);
      }
      const { data: pool, error: sErr } = await query;
      if (!sErr) {
        seedSample = shuffle(pool || []).slice(0, needSeed);
        usedSeedIds = seedSample.map((w) => w.id);
      }
    }

    const allWords = [
      ...userWords.slice(0, TARGET_VOCAB_SIZE),
      ...seedSample,
    ].slice(0, TARGET_VOCAB_SIZE);

    if (allWords.length === 0) {
      return res.status(500).json({
        error: 'NO_VOCABULARY',
        message: 'Vocabulary pool is empty. Seed words must be loaded into Supabase.',
      });
    }

    const vocabString = allWords
      .map(
        (w) =>
          `${w.article ? w.article + ' ' : ''}${w.word_nl} (${
            w.word_en || w.word_ru || '—'
          })`
      )
      .join(', ');

    // ---- LOAD RECENT EXERCISES ----
    const { data: recentRows } = await supabase
      .from('exercise_history')
      .select('stem, prompt_or_sentence')
      .eq('topic_code', topicCode)
      .order('created_at', { ascending: false })
      .limit(RECENT_DEDUP_WINDOW);
    const recentExercises = recentRows || [];

    // ---- RAG ----
    const { context: grammarContext, rules, title: topicTitle } =
      await retrieveGrammarContext({ topicCode });

    // ---- GENERATION LOOP ----
    // Combine session + DB recent into a "do not repeat" hint for the prompt.
    // Session sentences are most important; DB ones older.
    const avoidSentences = [
      ...recentSentences.slice(0, 10),
      ...(recentExercises || []).map((r) => r.prompt_or_sentence).slice(0, 10),
    ]
      .filter(Boolean)
      .slice(0, 15);

    const promptBuilder = PROMPTS[type];
    let { system, user } = promptBuilder({
      topic: topicCode,
      topicTitle: topicTitle || topicCode,
      vocabulary: vocabString,
      grammarContext,
      avoidSentences,
    });

    const guardrailLog = [];
    let attempt = 0;
    let lastErr = null;
    let parsed = null;
    let lastSoftWarnings = [];

    while (attempt < MAX_GENERATION_ATTEMPTS) {
      attempt++;
      const stageLog = { attempt, hard_failures: [], soft_warnings: [] };

      // === HARD CHECKS (trigger retry on failure) ===

      // 1. LLM call
      let raw;
      try {
        raw = await callClaude({ system, user, maxTokens: 400, temperature: 0.7 });
      } catch (e) {
        stageLog.hard_failures.push(`llm_call: ${e.message}`);
        guardrailLog.push(stageLog);
        lastErr = e;
        continue;
      }

      // 2. JSON parse
      try {
        parsed = parseJsonStrict(raw);
      } catch (e) {
        stageLog.hard_failures.push(`json_parse: ${e.message}`);
        guardrailLog.push(stageLog);
        lastErr = e;
        if (attempt === MAX_GENERATION_ATTEMPTS - 1) {
          system = `${system}\n\nIMPORTANT: Output STRICT JSON ONLY. No prose. No markdown. Start with { and end with }.`;
        }
        continue;
      }

      // 3. Schema validation
      const v = validateExercise(type, parsed);
      if (!v.valid) {
        stageLog.hard_failures.push(`schema: ${v.errors.join('; ')}`);
        guardrailLog.push(stageLog);
        lastErr = new Error(`Schema: ${v.errors.join('; ')}`);
        // Inject feedback into the user message for the next attempt
        user = `${user}\n\nPREVIOUS ATTEMPT FAILED — schema violation: ${v.errors.join('; ')}. Re-read the schema and fix this.`;
        continue;
      }

      // 4. Topic-specific structural validation (NEW — catches scheidbare/vast voorzetsel/modal issues)
      const struct = checkTopicStructure(parsed, topicCode);
      if (!struct.ok) {
        stageLog.hard_failures.push(`topic_structure: ${struct.errors.join('; ')}`);
        guardrailLog.push(stageLog);
        lastErr = new Error(`Topic structure: ${struct.errors.join('; ')}`);
        user = `${user}\n\nPREVIOUS ATTEMPT FAILED — topic rules violated: ${struct.errors.join('; ')}. Read the topic rules again and fix this.`;
        continue;
      }

      // 5. Topic relevance (rule-based, only for topics with rules)
      const rel = checkTopicRelevance(topicCode, type, parsed);
      if (!rel.ok) {
        stageLog.hard_failures.push(`topic_relevance: ${rel.reason} (${rel.label})`);
        guardrailLog.push(stageLog);
        lastErr = new Error(`Topic relevance: ${rel.reason}`);
        continue;
      }

      // 6. Difficulty (only A1-strict topics)
      const diff = checkDifficulty(topicCode, parsed);
      if (!diff.ok) {
        stageLog.hard_failures.push(`difficulty: ${diff.violations.join('; ')}`);
        guardrailLog.push(stageLog);
        lastErr = new Error(`Difficulty: ${diff.violations.join('; ')}`);
        continue;
      }

      // 7. Language mix (English in Dutch fields)
      const langMix = detectLanguageMix(parsed);
      if (!langMix.ok) {
        stageLog.hard_failures.push(`language_mix: ${langMix.intruders.join(', ')}`);
        guardrailLog.push(stageLog);
        lastErr = new Error(`Language mix: ${langMix.intruders.join(', ')}`);
        continue;
      }

      // === SOFT CHECKS (warning only) ===

      // 8. Vocabulary usage — soft (warn only)
      const vocabCheck = checkVocabularyUsage(parsed, allWords);
      if (vocabCheck.ratio > VOCAB_UNKNOWN_RATIO_THRESHOLD) {
        stageLog.soft_warnings.push(
          `vocab_unknown_ratio: ${(vocabCheck.ratio * 100).toFixed(0)}% (${vocabCheck.unknown.slice(0, 3).join(', ')})`
        );
      }

      // 9. Duplicate detection — TWO levels:
      //    a) Session-level (from client localStorage) — HARD retry
      //    b) DB-level (older history) — soft warning only
      const stem = exerciseStem(parsed, type);
      const canonical =
        type === 'sentence_building' ? parsed.expected : parsed.sentence;

      // (a) Session check — strict on early attempts, soft on the last
      const sessionRecent = recentSentences.map((s) => ({
        stem: '',
        prompt_or_sentence: s,
      }));
      const sessionDup = checkDuplicate(
        stem,
        canonical,
        sessionRecent,
        DEDUP_SIMILARITY_THRESHOLD
      );
      if (!sessionDup.ok) {
        if (attempt < MAX_GENERATION_ATTEMPTS) {
          stageLog.hard_failures.push(
            `session_duplicate: similar to "${sessionDup.similarTo}" (${sessionDup.score.toFixed(2)})`
          );
          guardrailLog.push(stageLog);
          lastErr = new Error(`Session duplicate: ${sessionDup.similarTo}`);
          user = `${user}\n\nPREVIOUS ATTEMPT FAILED — too similar to a sentence already shown. Generate something STRUCTURALLY different.`;
          continue;
        } else {
          stageLog.soft_warnings.push(
            `session_duplicate_accepted_on_final: similarity ${sessionDup.score.toFixed(2)}`
          );
        }
      }

      // (b) DB-history check — soft
      const dbDup = checkDuplicate(
        stem,
        canonical,
        recentExercises,
        DEDUP_SIMILARITY_THRESHOLD
      );
      if (!dbDup.ok) {
        stageLog.soft_warnings.push(
          `db_duplicate_accepted: similarity ${dbDup.score.toFixed(2)} to "${dbDup.similarTo}"`
        );
      }

      // === ALL HARD CHECKS PASSED ===
      guardrailLog.push(stageLog);
      lastSoftWarnings = stageLog.soft_warnings;

      // Persist to history
      try {
        await supabase.from('exercise_history').insert({
          topic_code: topicCode,
          exercise_type: type,
          prompt_or_sentence: canonical || '(no canonical)',
          stem,
        });
      } catch (e) {
        console.error('[history insert]', e);
      }

      return res.status(200).json({
        exercise: parsed,
        meta: {
          topic_code: topicCode,
          topic_title: topicTitle,
          type,
          prompt_version: PROMPT_VERSION,
          rag_rules_used: rules.map((r) => r.id),
          attempts: attempt,
          used_seed_word_ids: usedSeedIds,
          personalized: personalize,
          soft_warnings: lastSoftWarnings,
        },
      });
    }

    return res.status(502).json({
      error: 'GENERATION_FAILED',
      message: 'Failed to generate a valid exercise. Try a different topic.',
      details: lastErr?.message,
      guardrail_log: guardrailLog,
    });
  } catch (e) {
    if (e instanceof GuardrailError) {
      return res.status(400).json({ error: e.code, message: e.message });
    }
    console.error('[api/exercise]', e);
    return res.status(500).json({ error: 'INTERNAL', message: e.message });
  }
}
